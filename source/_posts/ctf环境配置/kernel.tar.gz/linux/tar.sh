#!/bin/sh
set -xe

#(cd driver; make clean)
rm -rf kernel
tar -zcvf ~/Desktop/blog/source/_posts/ctf环境配置/kernel.tar.gz -C .. $(basename $(readlink -f .))
