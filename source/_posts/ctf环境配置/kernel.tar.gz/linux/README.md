<h1 align="center">
    Kernel Pwn
</h1>

[![scripts test](https://github.com/JiaweiHawk/kernel_pwn/actions/workflows/main.yml/badge.svg)](https://github.com/JiaweiHawk/kernel_pwn/actions/)
