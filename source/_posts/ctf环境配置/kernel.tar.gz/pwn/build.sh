#!/bin/sh
set -xe

# 根文件系统路径
ROOT=$(pwd)/rootfs

# 文件系统映像路径
ROOTFS=$(pwd)/rootfs.cpio

# 内核镜像路径
KERNEL=$(pwd)/kernel

# exp源代码路径
EXP=$(pwd)/exp.c

# 生成内核
if [ ! -d ${KERNEL} ]; then
    VERSION=5.15.81
    wget --no-check-certificate https://mirrors.ustc.edu.cn/kernel.org/linux/kernel/v5.x/linux-${VERSION}.tar.xz
    tar -Jxvf linux-${VERSION}.tar.xz
    mv linux-${VERSION} kernel
    rm -rf linux-${VERSION}.tar.xz
    sudo apt-get install bison flex libelf-dev libssl-dev
    (cd kernel && make defconfig && make -j $(nproc))
fi

# 静态编译exp
gcc -Wall -o $(pwd)/rootfs/exp -static ${EXP}

# 生成内核驱动
make -C driver
cp driver/vuln.ko ${ROOT}

# 生成文件系统映像
(cd ${ROOT}; find . | cpio -o --format=newc > ${ROOTFS})

# 启动qemu
qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -monitor /dev/null \
    -serial mon:stdio \
    -kernel ${KERNEL}/arch/x86_64/boot/bzImage \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr' \
    -initrd ${ROOTFS} \
    -no-shutdown -no-reboot \
    -s
