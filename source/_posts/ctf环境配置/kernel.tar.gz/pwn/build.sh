#!/bin/sh
set -xe

# 根文件系统路径
ROOT=$(pwd)/rootfs

# 文件系统映像路径
ROOTFS=$(pwd)/rootfs.cpio

# 内核镜像路径
KERNEL=$(pwd)/kernel

# exp源代码路径
EXP=$(pwd)/exp.c

# 生成内核
if [ ! -d ${KERNEL} ]; then
    VERSION=5.15.81
    wget --no-check-certificate https://mirrors.ustc.edu.cn/kernel.org/linux/kernel/v5.x/linux-${VERSION}.tar.xz
    tar -Jxvf linux-${VERSION}.tar.xz
    mv linux-${VERSION} kernel
    rm -rf linux-${VERSION}.tar.xz

    sudo apt-get install bison flex libelf-dev libssl-dev

    (cd ${KERNEL} && make defconfig)

    # 开启userfaultfd机制
    sed -i 's/^# CONFIG_USERFAULTFD is not set$/CONFIG_HAVE_ARCH_USERFAULTFD_WP=y/' ${KERNEL}/.config
    sed -i '/^CONFIG_HAVE_ARCH_USERFAULTFD_WP=y$/a\CONFIG_HAVE_ARCH_USERFAULTFD_MINOR=y' ${KERNEL}/.config
    sed -i '/^CONFIG_HAVE_ARCH_USERFAULTFD_MINOR=y$/a\CONFIG_USERFAULTFD=y' ${KERNEL}/.config

    # 保存dwarf信息
    sed -i 's/^# CONFIG_DEBUG_INFO is not set$/CONFIG_DEBUG_INFO=y/' ${KERNEL}/.config
    sed -i '/^CONFIG_DEBUG_INFO=y$/a\# CONFIG_DEBUG_INFO_REDUCED is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_REDUCED is not set$/a\# CONFIG_DEBUG_INFO_COMPRESSED is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_COMPRESSED is not set$/a\# CONFIG_DEBUG_INFO_SPLIT is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_SPLIT is not set$/a\CONFIG_DEBUG_INFO_DWARF_TOOLCHAIN_DEFAULT=y' ${KERNEL}/.config
    sed -i '/^CONFIG_DEBUG_INFO_DWARF_TOOLCHAIN_DEFAULT=y$/a\# CONFIG_DEBUG_INFO_DWARF4 is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_DWARF4 is not set$/a\# CONFIG_DEBUG_INFO_DWARF5 is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_DWARF5 is not set$/a\# CONFIG_DEBUG_INFO_BTF is not set' ${KERNEL}/.config
    sed -i '/^# CONFIG_DEBUG_INFO_BTF is not set$/a\# CONFIG_GDB_SCRIPTS is not set' ${KERNEL}/.config

    # 开启msgrcv的MSG_COPY标志
    sed -i 's/^# CONFIG_CHECKPOINT_RESTORE is not set$/CONFIG_CHECKPOINT_RESTORE=y/' ${KERNEL}/.config
    sed -i 's/^# CONFIG_PROC_CHILDREN is not set$/CONFIG_PROC_CHILDREN=y/' ${KERNEL}/.config

    (cd ${KERNEL} && make -j $(nproc))
fi

# 静态编译exp
gcc -o $(pwd)/rootfs/exp -Werror -Wall -static ${EXP}

# 生成内核驱动
make -C driver
cp driver/vuln.ko ${ROOT}

# 生成文件系统映像
(cd ${ROOT}; find . | cpio -o --format=newc > ${ROOTFS})

# 启动qemu
qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -monitor /dev/null \
    -serial mon:stdio \
    -kernel ${KERNEL}/arch/x86_64/boot/bzImage \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr' \
    -initrd ${ROOTFS} \
    -no-shutdown -no-reboot \
    -s
