#!/bin/sh
set -x

# 判断apt是否安装软件
# 如果全部安装，则返回0
# 否则返回1
apt_search()
{
    for arg in "$@"
    do
        apt list --installed | grep "$arg";
        if [ ! "$?" = "0" ]; then
            return 1
        fi
    done
    return 0
}

# 根文件系统路径
ROOT=$(pwd)/rootfs

# 文件系统映像路径
ROOTFS=$(pwd)/rootfs.cpio

# 内核镜像路径
KERNEL=$(pwd)/kernel

# exp源代码路径
EXP=$(pwd)/exp.c

# 生成内核
if [ ! -d ${KERNEL} ]; then
    VERSION=5.15
    wget --no-check-certificate https://mirrors.ustc.edu.cn/kernel.org/linux/kernel/v$(echo ${VERSION} | awk -v FS='.' '{print $1}').x/linux-${VERSION}.tar.xz
    tar -Jxvf linux-${VERSION}.tar.xz
    mv linux-${VERSION} kernel
    rm -rf linux-${VERSION}.tar.xz

    apt_search bison flex libelf-dev libssl-dev
    if [ ! "$?" = "0" ]; then
        sudo apt-get install -y bison flex libelf-dev libssl-dev
    fi

    (cd ${KERNEL} && make defconfig)

    # 开启userfaultfd机制
    sed -i 's/^# CONFIG_USERFAULTFD is not set$/CONFIG_USERFAULTFD=y/' ${KERNEL}/.config

    # 保存dwarf信息
    sed -i 's/^# CONFIG_DEBUG_INFO is not set$/CONFIG_DEBUG_INFO=y/' ${KERNEL}/.config

    # 开启msgrcv的MSG_COPY标志
    sed -i 's/^# CONFIG_CHECKPOINT_RESTORE is not set$/CONFIG_CHECKPOINT_RESTORE=y/' ${KERNEL}/.config

    # 开启bpf
    sed -i 's/^# CONFIG_BPF_SYSCALL is not set$/CONFIG_BPF_SYSCALL=y/' ${KERNEL}/.config

    (cd ${KERNEL} && yes "" | make -j $(nproc))
fi

# 安装所需的依赖
apt_search libkeyutils-dev musl-tools
if [ ! "$?" = "0" ]; then
    sudo apt-get install -y libkeyutils-dev musl-tools
fi

# 静态编译exp
gcc -E -Werror -Wall -o $(pwd)/rootfs/exp.i ${EXP} \
    && musl-gcc -Os -Werror -Wall -static -o $(pwd)/rootfs/exp $(pwd)/rootfs/exp.i -lpthread \
    && strip -s $(pwd)/rootfs/exp \
    && rm -rf $(pwd)/rootfs/exp.i

# 生成内核驱动
make -C driver
cp driver/vuln.ko ${ROOT}

# 生成文件系统映像
(cd ${ROOT}; find . | cpio -o --format=newc > ${ROOTFS})

# 启动qemu
qemu-system-x86_64 \
    -m 128M \
    -nographic \
    -monitor /dev/null \
    -serial mon:stdio \
    -kernel ${KERNEL}/arch/x86_64/boot/bzImage \
    -append 'console=ttyS0 loglevel=3 oops=panic panic=1 nokaslr' \
    -initrd ${ROOTFS} \
    -no-shutdown -no-reboot \
    -s
