#!/bin/sh
set -xe

rm -rf kernel
tar -zcvf ~/Desktop/blog/source/_posts/ctf环境配置/kernel.tar.gz -C .. pwn
